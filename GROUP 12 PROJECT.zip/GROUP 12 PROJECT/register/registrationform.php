<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Registration Form</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
      body {
      font-family: 'Times New Roman', Times, serif; 
      background-image: url("4.jpg");
      background-repeat: no-repeat;
      background-size:2300px 1400px;
      }
            
      * {box-sizing: border-box}

      /* Full-width input fields */
      input[type=text], input[type=password] {
        width: 100%;
        padding: 15px;
        margin: 5px 0 22px 0;
        border: none;
        background: #f1f1f1;
      }

      input[type=text]:focus, input[type=password]:focus {
        background-color: #ddd;
        outline: none;
      }



      /* Set a style for all buttons */
      button {
        background-color: #4CAF50;
        color: white;
        padding: 14px 20px;
        margin: 8px 0;
        border: none;
        cursor: pointer;
        width: 100%;
        opacity: 0.9;
      }

      button:hover {
        opacity:1;
      }

      /* Extra styles for the cancel button */
      .cancelbtn {
        padding: 14px 20px;
        background-color: #f44336;
      }

      /* Float cancel and signup buttons and add an equal width */
      .cancelbtn, .registerbtn{
        float: left;
        width: 50%;
      }

      /* Add padding to container elements */
      .container {
        position: absolute;
        left: 350px;
        margin: 20px;
        max-width: 600px;
        padding: 16px;
        background-color: white;
        
      }


      /* Clear floats */
      .clearfix::after {
        content: "";
        clear: both;
        display: table;
      }

      /* Change styles for cancel button and signup button on extra small screens */
      @media screen and (max-width: 300px) {
        .cancelbtn, .registerbtn {
          width: 100%;
        }
      }
</style>
</head>
<body>
  <div>
<div class="w3-top">
    <div class="w3-bar w3-black w3-card">
      <a class="w3-bar-item w3-button w3-padding-large w3-hide-medium w3-hide-large w3-right" href="javascript:void(0)" onclick="myFunction()" title="Toggle Navigation Menu"><i class="fa fa-bars"></i></a>
      <a href="index.php" class="w3-bar-item w3-button w3-padding-large w3-hide-small">Home</a>
      <div class="topnav-right" style="float: right;">

      </div>
    </div>
</div>
  </div>
  <form action="./indexw.php" method="POST">    

  <div class="container"style="padding-left:50px">
    <h1 style="padding-top: 100px,">Registration</h1>
    <p>Please fill in this form for summer intership.</p>
    <hr>

    <label for=" Firstname"><b>First Name</b></label>
    <input type="text"  placeholder="Enter first name" name="Firstname" required><br>

    <label for=" Lastname"><b>Last Name</b></label>
    <input type="text"  placeholder="Enter Last name" name="Lastname" required><br>

    <label for="Email"><b>Email</b></label>
    <input type="text" placeholder="Enter Email" name="Email" required>

    <label for="Phoneno"><b>Phone Number</b></label>
    <input type="text"  placeholder="Enter Phone number" name="Phoneno" required><br>
<br>

    <lable for="Gender"><b>Gender:</b></lable>
          <input type="radio" id="Gender" name="Gender" value ="male" required/>Male
          <input type="radio" id="Gender" name="Gender" value ="female" required/>Female<br>
           <br>
          <label for="Birthdate">Birth Date:</label>
          <input type="date" id="Birthdate" name="Birthdate" required><br>
<br>
          <label for="Age"><b>Age</b></label>
        <input type="text" placeholder="Enter age" name="Age" required><br>
        <br>
        <label for="Nameoftheinstitute"><b>Name of the Institute</b></label>
        <input type="text" placeholder="Enter institute name" name="Nameoftheinstitute" required><br>
        <br>

        <label for="Yearandsemester"><b>Year & Semester</b></label>
    <input type="text"  placeholder="Your answer" name="Yearandsemester" required><br>
    <br>

    <label for="Branch"><b>Branch</b></label>
    <input type="text"  placeholder="Your answer" name="Branch" required><br>
    <br>
        <tr>
          <td class="tdLabel"><label for="Selectcourse" class="label" required><b>Select Course</b></label></td>
          <td><select name="Selectcourse" required id="Selectcourse" style="width:160px">
          <option value="Front-End">Frount-End </option>
          <option value="Back-End">Back-End</option>
          <option value="Full-Stack Software">Full-Stack Software</option>
          <option value="Information Security">Information Security</option>
          <option value="Mobile Engineering">Mobile Engineering</option>
          <option value="iOS Engineering">iOS Engineering</option>
          <option value="Graphic Designing">Graphic Designing</option>
          </select>
          </td>
          </tr><br>
          <br>
    <label>
      <input type="checkbox" checked="checked" name="remember" style="margin-bottom:15px"> Remember me
    </label>
    
    <p>By creating an account you agree to our <a href="#" style="color:dodgerblue">Terms & Privacy</a>.</p>

    <div class="clearfix">
    <a href="registrationform.php"><button type="button" class="cancelbtn">Cancel</button></a>
      <button type="submit" name="register" class="registerbtn">Register</button>
    </div>
  </div>
</form>
</body>
</html>