<!DOCTYPE html>
<html>
<head>
    <title>Login Form</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body, html {
  height: 100%;
  font-family: Arial, Helvetica, sans-serif;
  background-image: url("https://png.pngtree.com/thumb_back/fh260/back_our/20190620/ourmid/pngtree-university-admissions-association-recruits-new-image_169447.jpg");
  background-size: 100%;
}

* {
  box-sizing: border-box;
}
/* Add styles to the form container */
.container {
  position: absolute;
  left: 800px;
  top: 120px;
  margin: 20px;
  max-width: 300px;
  padding: 25px;
  height: 375px;
  background-color: white;
  padding-top: 10px;
  
}

/* Full-width input fields */
input[type=text], input[type=password] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  border: none;
  background: #f1f1f1;
}

input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

/* Set a style for the submit button */
.btn {
  background-color: #4CAF50;
  color: white;
  padding: 16px 20px;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

.btn:hover {
  opacity: 1;
}
</style>
</head>
<body>

<div class="w3-top">
    <div class="w3-bar w3-black w3-card">
      <a class="w3-bar-item w3-button w3-padding-large w3-hide-medium w3-hide-large w3-right" href="javascript:void(0)" onclick="myFunction()" title="Toggle Navigation Menu"><i class="fa fa-bars"></i></a>
      
      <div class="topnav-right" style="float: right;">
        <a href="login.php"class="w3-bar-item w3-button w3-padding-large w3-hide-small" >LOGIN</a>
      <a href="signup.php"class="w3-bar-item w3-button w3-padding-large w3-hide-small"  >SIGNUP</a>
      </div>
     </div>
    </div>
<div class="bg-img">
  <form method="post" action="process.php" class="container">
    
    <h1>Login</h1>

    <label for="Username"><b>Username</b></label>
    <input type="text" placeholder="Enter Username" name="Username" required>

    <label for="psw"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="psw" required>

    <button type="submit" class="btn">Login</button>
   
    <p>If you don't have an account? <a style="color: dodgerblue;" href="signup.php">Signup</a>.</p>
 
  </form>
  <?php if(isset($_GET['err'])){
	echo "<script>alert('Invalid Username or Password')</script>";
	} ?>
</div>
</body>
</html>