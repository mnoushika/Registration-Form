<?php
        #sample connection to database with name test
        $server = "localhost";
        $username = "root";
        $password = "";
        $dbname = "project"; #can be any name 
        $conn = new mysqli($server, $username, $password, $dbname);
        if($conn->connect_error){
            die("Connection failed.".$conn->connect_error);
        }else{
            if(isset($_REQUEST['register'])){
               if($_REQUEST['Firstname']!=""&&$_REQUEST['Lastname']!=""&&$_REQUEST['Email']!=""&&$_REQUEST['Phoneno']!=""&&$_REQUEST['Gender']!=NULL &&$_REQUEST['Birthdate']!=NULL&&$_REQUEST['Age']!=""&&$_REQUEST['Nameoftheinstitute']!=""&&$_REQUEST['Yearandsemester']!=""&&$_REQUEST['Branch']!=""){
                    $input = $_REQUEST['Firstname'];    
                    $input1 = $_REQUEST['Lastname'];
                    $input2 = $_REQUEST['Email'];
                    $input3 = $_REQUEST['Phoneno'];
                    $input4 = $_REQUEST['Gender'];
                    $input5 = $_REQUEST['Birthdate'];
                    $input6 = $_REQUEST['Age'];
                    $input7 = $_REQUEST['Nameoftheinstitute'];
                    $input8 = $_REQUEST['Yearandsemester'];
                    $input9 = $_REQUEST['Branch'];
                    $input10 = $_REQUEST['Selectcourse'];
                   
                    echo '<script>alert("Registration successfull")</script>';
                    echo("<script>windows: location='final.php'</script>");
                   
                    $sql = "INSERT INTO registration(Firstname,Lastname,Email,Phoneno,Gender,Birthdate,Age,Nameoftheinstitute,Yearandsemester,Branch,Selectcourse) VALUES('$input','$input1','$input2','$input3','$input4','$input5','$input6','$input7','$input8','$input9','$input10')";
                    if($conn->query($sql)===TRUE){
                        echo "\n\nThe value is taken into table";
                    }
                    else{
                      echo "\n error in executing";
                    }
                }else{
                    echo "\nThe value is not provided.";
                }

            }
        }
?>