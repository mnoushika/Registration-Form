-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 15, 2021 at 09:28 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `project`
--

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `id` int(11) NOT NULL,
  `Firstname` varchar(50) NOT NULL,
  `Lastname` varchar(50) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Phoneno` int(100) NOT NULL,
  `Gender` varchar(20) NOT NULL,
  `Birthdate` varchar(50) NOT NULL,
  `Age` int(50) NOT NULL,
  `Nameoftheinstitute` varchar(100) NOT NULL,
  `Yearandsemester` varchar(50) NOT NULL,
  `Branch` varchar(50) NOT NULL,
  `Selectcourse` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`id`, `Firstname`, `Lastname`, `Email`, `Phoneno`, `Gender`, `Birthdate`, `Age`, `Nameoftheinstitute`, `Yearandsemester`, `Branch`, `Selectcourse`) VALUES
(1, 'noushika', 'mothukuri', 'noushika15@gmail.com', 1490433224, 'female', '2021-04-05', 20, 'srm', '2nd and 4th semester', 'CSE', 'Front-End'),
(2, 'noushi', 'mothukuri', 'noushi15@gmail.com', 2147483647, 'female', '2021-04-12', 18, 'klu', '2nd and 4th semester', 'ece', 'Information Security'),
(3, 'kavya', 'surapaneni', 'kavya@gmail.com', 1567432167, 'female', '2021-04-06', 17, 'amritha', '2nd year 4th sem', 'eee', 'Mobile Engineering'),
(4, 'jaya', 'thatha', 'jaya15@gmail.com', 2147483647, 'female', '2021-04-14', 19, 'srm', '2nd and 3th semester', 'cse', 'Information Security');

-- --------------------------------------------------------

--
-- Table structure for table `signup`
--

CREATE TABLE `signup` (
  `Username` varchar(50) NOT NULL,
  `Firstname` varchar(50) NOT NULL,
  `Lastname` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `psw` varchar(50) NOT NULL,
  `cpsw` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `signup`
--

INSERT INTO `signup` (`Username`, `Firstname`, `Lastname`, `email`, `phone`, `psw`, `cpsw`) VALUES
('jaya15', 'jayasree', 'thatha', 'jaya10@gmail.com', '6302532052', '56789', '56789'),
('noushika15', 'noushika', 'mothukuri', 'noushika15@gmail.com', '9533234666', '1234', '1234'),
('rushi', 'rushika', 'chinnu', 'rushika17@gmail.com', '4567432167', '5678', '5678'),
('shyam', 'sundar', 'kotapati', 'shyam@gmail.com', '9876543210', '987', '987');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `signup`
--
ALTER TABLE `signup`
  ADD UNIQUE KEY `Username` (`Username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
