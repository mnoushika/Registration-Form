<!DOCTYPE HTML>
<html>
<head>
    <title> Demo </title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <style>
        .title{
            text-align: center;
            background-color: black;
            color: #fff;
            padding-bottom: 20px;
        }
        .YIntern{
            text-align: center;
        }
        .first{
            display:flex;
        }
        .first div{
            flex :1;
        }
        .first ul{
            list-style-type: none;
        }
        .contact{
          background-color: black;
          color: white;
          padding: 10px;
         }
         .contact p{
           padding-left: 20px;
         }
        
    </style>
</head>
<body>
    <div class="w3-top">
        <div class="w3-bar w3-black w3-card">
          <a class="w3-bar-item w3-button w3-padding-large w3-hide-medium w3-hide-large w3-right" href="javascript:void(0)" onclick="myFunction()" title="Toggle Navigation Menu"><i class="fa fa-bars"></i></a>
        <div class="topnav-right" style="float: right;">
          <a href="login.php"class="w3-bar-item w3-button w3-padding-large w3-hide-small" >LOGIN</a>
          <a href="signup.php"class="w3-bar-item w3-button w3-padding-large w3-hide-small"  >SIGNUP</a>
        </div>
        </div>
    </div>
<br>
<br>
<div class="title"><h1><b>Apply for Summer Internship</b></h1>
<div class="YIntern"><h2><b>Why should you intern?</b></h2>
<section class="first">
    <div>
        <ul>
            <li><h4>Application of education and career exploration</h4></li>
            <li><h4>Gain experience and increase marketability</h4></li>
            <li><h4>Networking</h4></li>
            <li><h4>National Data</h4></li>
            <li><h4>Professionalism</h4></li>
        </ul>
    </div>
    <div>
        <ul>
            <li><h4>how a professional workplace operates</h4></li>
            <li><h4>Build your resume</h4></li>
            <li><h4>Gain professional feedback</h4></li>
            <li><h4>Learn from others</h4></li>
            <li><h4>Figure out what you like and don’t like</h4></li>
        </ul>
    </div>
    </section>
</div>
</div>
<br>
<div class="container">
    <div id="myCarousel" class="carousel slide" data-ride="carousel">
      <!-- Indicators -->
      <ol class="carousel-indicators">
        <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
        <li data-target="#myCarousel" data-slide-to="1"></li>
        <li data-target="#myCarousel" data-slide-to="2"></li>
      </ol>
      <!-- Wrapper for slides -->
      <div class="carousel-inner">
        <div class="item active">
          <img src="3.jpg" style="width:100%;">
        </div>
        <div class="item">
          <img src="1.png"  style="width:100%;">
        </div>
        <div class="item">
          <img src="2.png"  style="width:100%;">
        </div>
      </div>
      <!-- Left and right controls -->
      <a class="left carousel-control" href="#myCarousel" data-slide="prev">
        <span class="glyphicon glyphicon-chevron-left"></span>
        <span class="sr-only">Previous</span>
      </a>
      <a class="right carousel-control" href="#myCarousel" data-slide="next">
        <span class="glyphicon glyphicon-chevron-right"></span>
        <span class="sr-only">Next</span>
      </a>
    </div>
  </div>
<br>
  <div class="contact">
      <h3 style=" text-align: center; font-family:'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif"><u>For Further Details</u>:</h3>
      <h4><strong style="color:violet; ">Call:</strong> +91-866-2429299/ 1800-599-2233 (Toll Free)</h4>
      <h4><strong  style="color:violet;">Email:</strong> internshipreg@gmail.com</h4>
      <h4><strong  style="color:violet;">Address:</strong> Neerukonda, Mangalagiri Mandal
                   Guntur District, Mangalagiri, 
                   Andhra Pradesh 522240.</h4>
    </div>
</body>
</html>
